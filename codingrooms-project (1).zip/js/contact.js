function showSocialAnxiety() {
    let submitButton = document.getElementById('submit');

    submitButton.innerHTML = "sorry, the submit button is disbaled until the author is emotionally available. come back later!";
}